<?php



$db = mysqli_connect('localhost', 'root','', 'new');
 
$email =$_POST['email'];


$query = "INSERT INTO subs(email) 
  			  VALUES('$email')";
  	mysqli_query($db,$query);
  header('location:index.php');

?>