<?php



$db = mysqli_connect('localhost', 'root','', 'new');

$name = $_POST['name']; 
$email =$_POST['email'];
$phone = $_POST['phone'];
$message =$_POST['message'];


$query = "INSERT INTO contact(name, email, phone, message) 
  			  VALUES('$name', '$email', '$phone','$message')";
  	mysqli_query($db,$query);
  header('location:contact.php');

?>