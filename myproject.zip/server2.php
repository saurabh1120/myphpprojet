
<?php

session_start();

$username = "";
$password  = "";
$errors = array(); 


$db = mysqli_connect('localhost', 'root', '', 'new');

if (isset($_POST['login'])) 
{
  
  $username = mysqli_real_escape_string($db, $_POST['username']);
  $password = mysqli_real_escape_string($db, $_POST['password']);

  
  if (empty($username)) { array_push($errors, "Username is required"); }
  if (empty($password_1)) { array_push($errors, "Password is required"); }

  	$query = "SELECT * FROM signup WHERE username='".$username."' AND password='".$password."' ";
  	$sql = mysqli_query($db, $query);
	$count_rows= mysqli_num_rows($sql);
	if($count_rows!=0)
	{
	 $rowchk= mysqli_fetch_array($sql);
	  $_SESSION['username'] = $username;
  	 $_SESSION['success'] = "You are now logged in";
  	 
	 header("location:products.php");
	}
	else
	{

echo "<h1>Incorrect password</h1>";

echo "<h3>To login, back and try again</h3>";


	}
  	
}
?>


<html>
<head>
<style>

.button {
  background-color: #89cff0;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
</head>

<body img background="images/45.jpg">
<form action="login.php" method="post">
<input type="submit" class="button" value="BACK">
</form>
</body>
</html>
